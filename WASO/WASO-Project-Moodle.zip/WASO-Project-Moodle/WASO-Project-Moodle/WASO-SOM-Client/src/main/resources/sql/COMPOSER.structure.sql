CREATE TABLE COMPOSER (
  ClientID int NOT NULL,
  PersonneID int NOT NULL,
  PRIMARY KEY (ClientID,PersonneID)
)
