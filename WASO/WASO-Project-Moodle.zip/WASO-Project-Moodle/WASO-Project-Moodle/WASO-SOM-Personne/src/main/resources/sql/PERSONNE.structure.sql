CREATE TABLE PERSONNE (
  PersonneID int NOT NULL PRIMARY KEY,
  Civilite varchar(5) NOT NULL,
  Nom varchar(255) NOT NULL,
  Prenom varchar(255) NOT NULL,
  Mail varchar(255)
)
